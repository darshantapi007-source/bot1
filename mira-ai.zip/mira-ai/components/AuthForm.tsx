'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase-browser'
export default function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const router = useRouter()
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const [err, setErr] = useState(''); const [info, setInfo] = useState(''); const [busy, setBusy] = useState(false)
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setInfo(''); setBusy(true)
    const sb = createClient()
    if (mode === 'login') {
      const { error } = await sb.auth.signInWithPassword({ email, password })
      if (error) setErr(error.message); else { router.push('/chat'); router.refresh() }
    } else {
      const { data, error } = await sb.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/auth/callback` } })
      if (error) setErr(error.message)
      else if (data.session) { router.push('/chat'); router.refresh() }
      else setInfo('Check your email for a confirmation link, then log in.')
    }
    setBusy(false)
  }
  return (<main className="grid min-h-screen place-items-center px-5">
    <form onSubmit={submit} className="glass w-full max-w-sm space-y-4 rounded-[2rem] p-8">
      <Link href="/" className="font-display text-2xl font-bold">Mira</Link>
      <h1 className="text-xl font-semibold">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
      <label className="block text-sm font-medium">Email<input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-2xl border border-lav bg-white/80 px-4 py-3" /></label>
      <label className="block text-sm font-medium">Password<input type="password" required minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 w-full rounded-2xl border border-lav bg-white/80 px-4 py-3" /></label>
      {err && <p role="alert" className="text-sm text-rose">{err}</p>}
      {info && <p className="text-sm text-orchid">{info}</p>}
      <button disabled={busy} className="btn btn-primary w-full">{busy ? 'One moment…' : mode === 'login' ? 'Log in' : 'Sign up'}</button>
      <p className="text-center text-sm">{mode === 'login' ? <>New here? <Link className="font-semibold text-rose" href="/signup">Sign up</Link></> : <>Have an account? <Link className="font-semibold text-rose" href="/login">Log in</Link></>}</p>
    </form></main>)
}
