import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { createClient } from '@/lib/supabase-server'
import { MIRA_PROMPT, updateMemory } from '@/lib/mira'
export const runtime = 'nodejs'
export const maxDuration = 60
const fail = (error: string, status: number) => NextResponse.json({ error }, { status })

export async function POST(req: NextRequest) {
  const sb = await createClient()
  const { data: { user } } = await sb.auth.getUser()
  if (!user) return fail('Please log in.', 401)
  if (!process.env.OPENAI_API_KEY) return fail('The server is missing its OpenAI key.', 500)
  let body: any
  try { body = await req.json() } catch { return fail('Invalid request.', 400) }
  const message = typeof body.message === 'string' ? body.message.trim() : ''
  if (!message || message.length > 4000) return fail('Message must be 1–4000 characters.', 400)

  const since = new Date(Date.now() - 60_000).toISOString()
  const { count } = await sb.from('chat_requests').select('*', { count: 'exact', head: true }).gte('created_at', since)
  if ((count ?? 0) >= 15) return fail('Slow down a little. Try again in a minute.', 429)
  await sb.from('chat_requests').insert({ user_id: user.id })

  let cid: string | null = typeof body.conversationId === 'string' ? body.conversationId : null
  if (cid) {
    const { data } = await sb.from('conversations').select('id').eq('id', cid).maybeSingle()
    if (!data) return fail('Conversation not found.', 404)
  } else {
    const { data, error } = await sb.from('conversations').insert({ title: message.slice(0, 48) }).select('id').single()
    if (error || !data) return fail('Could not start a conversation.', 500)
    cid = data.id
  }
  const { error: insErr } = await sb.from('messages').insert({ conversation_id: cid, role: 'user', content: message })
  if (insErr) return fail('Could not save your message.', 500)

  const words = (message.toLowerCase().match(/\p{L}{4,}/gu) ?? []).slice(0, 8).join(' or ')
  const [hist, recent, found, past] = await Promise.all([
    sb.from('messages').select('role,content').eq('conversation_id', cid).order('created_at', { ascending: false }).limit(20),
    sb.from('memories').select('id,content').order('updated_at', { ascending: false }).limit(10),
    words ? sb.from('memories').select('id,content').textSearch('tsv', words, { type: 'websearch', config: 'simple' }).limit(8) : Promise.resolve({ data: [] as any[] }),
    words ? sb.from('messages').select('content').eq('role', 'user').neq('conversation_id', cid).textSearch('tsv', words, { type: 'websearch', config: 'simple' }).limit(3) : Promise.resolve({ data: [] as any[] }),
  ])
  const mem = new Map<string, string>()
  ;[...(found.data ?? []), ...(recent.data ?? [])].forEach((m: any) => mem.set(m.id, m.content))
  let system = MIRA_PROMPT
  if (mem.size) system += `\n\nWhat you remember about this user:\n${[...mem.values()].map((m) => '- ' + m).join('\n')}`
  if (past.data?.length) system += `\n\nThings they said in earlier chats that may be related:\n${past.data.map((m: any) => '- ' + String(m.content).slice(0, 200)).join('\n')}`

  const openai = new OpenAI()
  const history = (hist.data ?? []).reverse().map((m: any) => ({ role: m.role as 'user' | 'assistant', content: m.content as string }))
  const enc = new TextEncoder()
  const stream = new ReadableStream({
    async start(ctrl) {
      let full = ''
      try {
        const s = await openai.chat.completions.create({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', stream: true, temperature: 0.9, messages: [{ role: 'system', content: system }, ...history] })
        for await (const part of s) {
          const t = part.choices[0]?.delta?.content || ''
          if (t) { full += t; ctrl.enqueue(enc.encode(t)) }
        }
        if (full) {
          await sb.from('messages').insert({ conversation_id: cid, role: 'assistant', content: full })
          await sb.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', cid)
          await updateMemory(openai, sb, user.id, message, full)
        }
      } catch (e) {
        console.error('chat failed', e)
        if (!full) ctrl.enqueue(enc.encode("I can't reach my brain right now. Try again in a moment."))
      }
      ctrl.close()
    },
  })
  return new Response(stream, { headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'X-Conversation-Id': cid! } })
}
