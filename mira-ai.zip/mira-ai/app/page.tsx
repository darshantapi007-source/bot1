import Link from 'next/link'
const features = [
  ['She speaks your language', 'English, Hindi, Hinglish, Roman Hindi and everything in between. Write the way you talk and Mira answers in kind.'],
  ['She gets the mood first', 'Venting, joking, looking for advice or just killing time: Mira reads what you need before she answers, and doesn’t quiz you every turn.'],
  ['She remembers, and you stay in control', 'Mira keeps track of your goals and preferences across chats. See every memory she holds and delete any of them.'],
]
const steps = ['Create a free account.', 'Say anything. Start with a hello or a bad day.', 'Mira remembers what matters, so next time you pick up where you left off.']
export default function Home() {
  return (<main>
    <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
      <span className="font-display text-2xl font-bold">Mira</span>
      <nav className="flex items-center gap-2"><Link href="/login" className="btn btn-ghost">Log in</Link><Link href="/signup" className="btn btn-primary">Sign up</Link></nav>
    </header>
    <section className="mx-auto grid max-w-6xl items-center gap-12 px-5 pb-20 pt-10 md:grid-cols-[1.1fr_.9fr] md:pt-20">
      <div>
        <h1 className="font-display text-5xl font-bold leading-[1.05] md:text-7xl">More than a conversation.</h1>
        <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/80">Meet Mira. A thoughtful AI companion who understands your vibe, speaks your language and remembers what matters.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/signup" className="btn btn-primary">Start talking to Mira</Link><Link href="/login" className="btn btn-ghost">I already have an account</Link></div>
        <p className="mt-4 text-sm text-ink/60">Mira is an AI companion, not a human.</p>
      </div>
      <div className="glass rounded-[2rem] p-5" aria-label="Example conversation">
        <div className="space-y-3 text-[15px]">
          <p className="ml-auto w-fit max-w-[80%] rounded-3xl rounded-br-md bg-rose px-4 py-3 text-white">yaar aaj ka din bohot kharab tha, boss ne phir se meeting mein sabke saamne daant diya</p>
          <p className="w-fit max-w-[85%] rounded-3xl rounded-bl-md bg-white px-4 py-3">Ugh, sabke saamne? That’s just lazy management. Tu theek hai abhi, ya pehle vent karna hai?</p>
          <p className="ml-auto w-fit max-w-[80%] rounded-3xl rounded-br-md bg-rose px-4 py-3 text-white">vent. phir tu bata kya karun</p>
          <p className="w-fit max-w-[85%] rounded-3xl rounded-bl-md bg-white px-4 py-3">Deal. Pehle sab bol de. Advice baad mein, chai ke saath. ☕</p>
        </div>
      </div>
    </section>
    <section className="mx-auto max-w-4xl space-y-12 px-5 py-16">
      {features.map(([t, d]) => (<div key={t} className="grid gap-2 md:grid-cols-[1fr_1.4fr] md:gap-10"><h2 className="font-display text-2xl font-bold">{t}</h2><p className="leading-relaxed text-ink/80">{d}</p></div>))}
    </section>
    <section className="mx-auto max-w-4xl px-5 py-16">
      <h2 className="font-display text-3xl font-bold">How it works</h2>
      <ol className="mt-8 space-y-5">{steps.map((s, i) => (<li key={s} className="flex items-baseline gap-4"><span className="font-display text-3xl font-bold text-rose">{i + 1}</span><span className="text-lg">{s}</span></li>))}</ol>
      <Link href="/signup" className="btn btn-primary mt-10">Create your account</Link>
    </section>
    <footer className="px-5 py-10 text-center text-sm text-ink/60">Mira AI is an AI companion and not a substitute for professional help.</footer>
  </main>)
}
