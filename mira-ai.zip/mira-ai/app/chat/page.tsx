'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase-browser'
type Msg = { id: string; role: 'user' | 'assistant'; content: string; created_at: string }
type Conv = { id: string; title: string; updated_at: string }
const time = (s: string) => new Date(s).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })

export default function Chat() {
  const sb = useMemo(() => createClient(), [])
  const [convs, setConvs] = useState<Conv[]>([]); const [active, setActive] = useState<string | null>(null)
  const [msgs, setMsgs] = useState<Msg[]>([]); const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [loading, setLoading] = useState(true); const [nav, setNav] = useState(false)
  const end = useRef<HTMLDivElement>(null)
  const loadConvs = async () => { const { data, error } = await sb.from('conversations').select('id,title,updated_at').order('updated_at', { ascending: false }); if (error) setErr('Could not load your chats.'); else setConvs(data ?? []); setLoading(false) }
  useEffect(() => { loadConvs() }, [])
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])
  async function open(id: string | null) {
    setActive(id); setNav(false); setErr('')
    if (!id) { setMsgs([]); return }
    const { data, error } = await sb.from('messages').select('id,role,content,created_at').eq('conversation_id', id).order('created_at')
    if (error) setErr('Could not load this chat.'); else setMsgs(data as Msg[])
  }
  async function send() {
    const text = input.trim(); if (!text || busy) return
    setInput(''); setErr(''); setBusy(true)
    const now = new Date().toISOString()
    setMsgs((m) => [...m, { id: 'u' + now, role: 'user', content: text, created_at: now }, { id: 'a' + now, role: 'assistant', content: '', created_at: now }])
    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversationId: active, message: text }) })
      if (!res.ok || !res.body) { const j = await res.json().catch(() => ({})); throw new Error(j.error || 'Something went wrong. Try again.') }
      const cid = res.headers.get('X-Conversation-Id'); if (cid) setActive(cid)
      const reader = res.body.getReader(); const dec = new TextDecoder(); let acc = ''
      for (;;) { const { done, value } = await reader.read(); if (done) break; acc += dec.decode(value, { stream: true }); setMsgs((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, content: acc } : x))) }
      loadConvs()
    } catch (e: any) { setErr(e.message); setMsgs((m) => m.slice(0, -2)); setInput(text) } finally { setBusy(false) }
  }
  async function clearChat() { if (!active || !confirm('Delete every message in this chat?')) return; const { error } = await sb.from('messages').delete().eq('conversation_id', active); if (error) setErr('Could not clear the chat.'); else setMsgs([]) }
  async function removeChat(id: string) { if (!confirm('Delete this conversation?')) return; const { error } = await sb.from('conversations').delete().eq('id', id); if (error) setErr('Could not delete the chat.'); else { if (id === active) open(null); loadConvs() } }
  async function logout() { await sb.auth.signOut(); location.href = '/' }
  const typing = busy && msgs.length > 0 && msgs[msgs.length - 1].content === ''

  return (<div className="flex h-[100dvh]">
    <aside className={`glass fixed inset-y-0 left-0 z-20 flex w-72 flex-col p-4 transition-transform md:static md:translate-x-0 ${nav ? '' : '-translate-x-full'}`}>
      <div className="mb-4 flex items-center justify-between"><span className="font-display text-2xl font-bold">Mira</span><button className="md:hidden" onClick={() => setNav(false)} aria-label="Close menu">✕</button></div>
      <button className="btn btn-primary mb-3" onClick={() => open(null)}>New conversation</button>
      <div className="flex-1 space-y-1 overflow-y-auto">
        {loading && <p className="p-2 text-sm text-ink/60">Loading…</p>}
        {!loading && !convs.length && <p className="p-2 text-sm text-ink/60">No chats yet. Say hi to Mira.</p>}
        {convs.map((c) => (<div key={c.id} className={`group flex items-center rounded-2xl ${c.id === active ? 'bg-white' : 'hover:bg-white/60'}`}>
          <button onClick={() => open(c.id)} className="min-w-0 flex-1 px-3 py-2 text-left"><span className="block truncate text-sm font-medium">{c.title}</span><span className="text-xs text-ink/50">{new Date(c.updated_at).toLocaleDateString()}</span></button>
          <button onClick={() => removeChat(c.id)} className="px-3 text-ink/40 hover:text-rose" aria-label={`Delete ${c.title}`}>✕</button></div>))}
      </div>
      <div className="mt-3 flex gap-2 border-t border-lav pt-3 text-sm"><Link href="/settings" className="btn btn-ghost flex-1 !py-2">Settings &amp; memory</Link><button onClick={logout} className="btn btn-ghost !py-2">Log out</button></div>
    </aside>
    <section className="flex min-w-0 flex-1 flex-col">
      <header className="flex items-center justify-between px-4 py-3"><button className="md:hidden" onClick={() => setNav(true)} aria-label="Open menu">☰</button><span className="text-sm text-ink/60">Mira is an AI companion</span>{active ? <button onClick={clearChat} className="text-sm text-ink/60 hover:text-rose">Clear chat</button> : <span />}</header>
      <div className="flex-1 overflow-y-auto px-4">
        <div className="mx-auto max-w-2xl space-y-3 pb-6">
          {!msgs.length && <div className="pt-24 text-center"><h1 className="font-display text-4xl font-bold">Hey, I’m Mira.</h1><p className="mt-2 text-ink/70">Tell me what’s on your mind, in any language.</p></div>}
          {msgs.map((m) => (<div key={m.id} className={m.role === 'user' ? 'flex flex-col items-end' : 'flex flex-col items-start'}>
            {(m.content || m.role === 'user') && <p className={`max-w-[85%] whitespace-pre-wrap rounded-3xl px-4 py-3 ${m.role === 'user' ? 'rounded-br-md bg-rose text-white' : 'glass rounded-bl-md'}`}>{m.content}</p>}
            {m.content && <span className="mt-1 px-2 text-xs text-ink/40">{time(m.created_at)}</span>}</div>))}
          {typing && <div className="glass flex w-fit gap-1.5 rounded-3xl rounded-bl-md px-4 py-4" aria-label="Mira is typing">{[0, 1, 2].map((i) => <span key={i} className="dot h-2 w-2 rounded-full bg-orchid" style={{ animationDelay: `${i * 0.2}s` }} />)}</div>}
          <div ref={end} />
        </div>
      </div>
      <div className="mx-auto w-full max-w-2xl px-4 pb-4">
        {err && <p role="alert" className="mb-2 text-sm text-rose">{err}</p>}
        <div className="glass flex items-end gap-2 rounded-3xl p-2">
          <textarea value={input} rows={1} maxLength={4000} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }} placeholder="Message Mira…" aria-label="Message" className="max-h-40 flex-1 resize-none bg-transparent px-3 py-2 outline-none" />
          <button onClick={send} disabled={busy || !input.trim()} className="btn btn-primary">Send</button>
        </div>
      </div>
    </section></div>)
}
