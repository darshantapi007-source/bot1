import './globals.css'
import type { Metadata, Viewport } from 'next'
export const metadata: Metadata = { title: 'Mira AI: more than a conversation', description: 'A thoughtful AI companion who understands your vibe, speaks your language and remembers what matters.' }
export const viewport: Viewport = { width: 'device-width', initialScale: 1 }
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><head>
    <link rel="preconnect" href="https://fonts.googleapis.com" /><link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Manrope:wght@400;500;600;700&display=swap" rel="stylesheet" />
  </head><body className="font-sans antialiased">{children}</body></html>)
}
