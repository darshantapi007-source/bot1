'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { createClient } from '@/lib/supabase-browser'
type Mem = { id: string; content: string; updated_at: string }
export default function Settings() {
  const [mems, setMems] = useState<Mem[]>([]); const [text, setText] = useState(''); const [email, setEmail] = useState('')
  const [err, setErr] = useState(''); const [loading, setLoading] = useState(true)
  async function load() { const r = await fetch('/api/memories'); const j = await r.json().catch(() => ({})); if (!r.ok) setErr(j.error || 'Could not load memories.'); else setMems(j.memories); setLoading(false) }
  useEffect(() => { load(); createClient().auth.getUser().then(({ data }) => setEmail(data.user?.email ?? '')) }, [])
  async function add(e: React.FormEvent) { e.preventDefault(); if (!text.trim()) return; setErr(''); const r = await fetch('/api/memories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text }) }); const j = await r.json().catch(() => ({})); if (!r.ok) setErr(j.error || 'Could not save.'); else { setMems((m) => [j.memory, ...m]); setText('') } }
  async function del(id?: string) { if (!id && !confirm('Delete everything Mira remembers about you?')) return; const r = await fetch('/api/memories' + (id ? `?id=${id}` : ''), { method: 'DELETE' }); if (!r.ok) setErr('Could not delete.'); else setMems((m) => (id ? m.filter((x) => x.id !== id) : [])) }
  return (<main className="mx-auto max-w-2xl px-5 py-8">
    <Link href="/chat" className="text-sm font-semibold text-rose">Back to chat</Link>
    <h1 className="mt-4 font-display text-4xl font-bold">Settings</h1>
    <p className="mt-1 text-ink/70">Signed in as {email || '…'}</p>
    <h2 className="mt-10 font-display text-2xl font-bold">What Mira remembers</h2>
    <p className="mt-1 text-sm text-ink/70">Mira saves lasting details from your chats. Add, correct or delete anything here.</p>
    <form onSubmit={add} className="mt-4 flex gap-2"><input value={text} maxLength={200} onChange={(e) => setText(e.target.value)} placeholder="e.g. I’m training for a half marathon" aria-label="New memory" className="flex-1 rounded-full border border-lav bg-white/80 px-4 py-3" /><button className="btn btn-primary">Add memory</button></form>
    {err && <p role="alert" className="mt-3 text-sm text-rose">{err}</p>}
    <ul className="mt-6 space-y-2">
      {loading && <li className="text-ink/60">Loading…</li>}
      {!loading && !mems.length && <li className="text-ink/60">Nothing yet. Mira will pick up details as you chat.</li>}
      {mems.map((m) => (<li key={m.id} className="glass flex items-center justify-between gap-3 rounded-2xl px-4 py-3"><span>{m.content}</span><button onClick={() => del(m.id)} className="text-sm text-ink/50 hover:text-rose">Delete</button></li>))}
    </ul>
    {mems.length > 0 && <button onClick={() => del()} className="btn btn-ghost mt-6">Delete all memories</button>}
  </main>)
}
