# Mira AI
Next.js 15 (App Router) + TypeScript + Tailwind + OpenAI + Supabase.

## Local setup
1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in the values.
3. In Supabase → SQL Editor, run `supabase/schema.sql`.
4. `npm run dev`

## Supabase configuration
- Authentication → URL Configuration: set Site URL to your Vercel URL and add `https://YOUR-DOMAIN/auth/callback` (and `http://localhost:3000/auth/callback`) to Redirect URLs.
- Authentication → Providers → Email: keep enabled. Turn off "Confirm email" if you want instant signup.

## Deploy to Vercel
1. Push this folder to GitHub and import it in Vercel (framework: Next.js, defaults).
2. Add env vars: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `OPENAI_API_KEY` (optional `OPENAI_MODEL`).
3. Deploy. Then update the Supabase Site URL/redirect to the final domain.

## Manual checklist
- [ ] Supabase project created, `schema.sql` run
- [ ] Redirect URLs set in Supabase
- [ ] OpenAI key with billing enabled
- [ ] Env vars set in Vercel (all environments)
- [ ] Vercel function timeout: chat route uses `maxDuration = 60` (Hobby plan may cap lower)

## Notes
- Rate limit: 15 chat requests/minute/user, stored in `chat_requests` (delete old rows periodically).
- Memory retrieval uses Postgres full-text search (no embeddings).
