import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase-server'
export const runtime = 'nodejs'
export async function GET() {
  const sb = await createClient()
  const { data, error } = await sb.from('memories').select('id,content,updated_at').order('updated_at', { ascending: false })
  if (error) return NextResponse.json({ error: 'Could not load memories.' }, { status: 500 })
  return NextResponse.json({ memories: data })
}
export async function POST(req: NextRequest) {
  const sb = await createClient()
  const { content } = await req.json().catch(() => ({}))
  if (typeof content !== 'string' || !content.trim() || content.length > 200) return NextResponse.json({ error: 'Memory must be 1–200 characters.' }, { status: 400 })
  const { data, error } = await sb.from('memories').insert({ content: content.trim() }).select('id,content,updated_at').single()
  if (error) return NextResponse.json({ error: 'Could not save memory.' }, { status: 500 })
  return NextResponse.json({ memory: data })
}
export async function DELETE(req: NextRequest) {
  const sb = await createClient()
  const id = req.nextUrl.searchParams.get('id')
  const q = id ? sb.from('memories').delete().eq('id', id) : sb.from('memories').delete().not('id', 'is', null)
  const { error } = await q
  if (error) return NextResponse.json({ error: 'Could not delete.' }, { status: 500 })
  return NextResponse.json({ ok: true })
}
