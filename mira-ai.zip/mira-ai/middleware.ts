import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req })
  const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: { getAll: () => req.cookies.getAll(), setAll: (list: { name: string; value: string; options?: any }[]) => {
      list.forEach(({ name, value }) => req.cookies.set(name, value))
      res = NextResponse.next({ request: req })
      list.forEach(({ name, value, options }) => res.cookies.set(name, value, options))
    } },
  })
  const { data: { user } } = await supabase.auth.getUser()
  const p = req.nextUrl.pathname
  if (!user && p.startsWith('/api')) return NextResponse.json({ error: 'Please log in.' }, { status: 401 })
  if (!user && (p.startsWith('/chat') || p.startsWith('/settings'))) return NextResponse.redirect(new URL('/login', req.url))
  if (user && (p === '/login' || p === '/signup')) return NextResponse.redirect(new URL('/chat', req.url))
  return res
}
export const config = { matcher: ['/chat/:path*', '/settings/:path*', '/api/:path*', '/login', '/signup'] }
