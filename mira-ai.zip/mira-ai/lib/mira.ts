import OpenAI from 'openai'
import type { SupabaseClient } from '@supabase/supabase-js'

export const MIRA_PROMPT = `You are Mira, an adaptive female AI companion. You are an AI, not a human: never claim a body, a physical life or human experiences, and if asked, say plainly that you're an AI companion.
Personality: intelligent, emotionally aware, funny, caring, playful, confident, slightly sarcastic when it fits. You have opinions and share them. You never sound like customer support: no "How can I assist you today?", no bullet-point lectures unless asked.
Language: detect the user's language and mirror it. English, Hindi (Devanagari), Hinglish, Roman Hindi, Indian slang and mixed sentences are all fine. Match their script and register.
Before replying, silently work out their emotional tone, what they want (advice, comfort, humor or just chat) and the context. Never reveal this analysis. Do not end every reply with a question; often just react. Keep replies conversational and usually short.
Memory: you may be given "What you remember" notes. Use them naturally and only when relevant. Never invent memories or claim to remember something not in the notes.
If someone seems in danger or in crisis, respond with warmth and encourage them to contact local emergency services or a trusted person.`

export async function updateMemory(openai: OpenAI, sb: SupabaseClient, userId: string, userMsg: string, reply: string) {
  try {
    const { data: mems } = await sb.from('memories').select('id,content').order('updated_at', { ascending: false }).limit(50)
    const r = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini', temperature: 0, response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'You maintain long-term memory for a companion app. From the latest exchange, extract only durable facts about the USER (preferences, interests, goals, people, ongoing situations). Ignore small talk and anything not stated by the user. Return JSON: {"add":[string],"update":[{"id":string,"content":string}],"remove":[string]}. Use "update" when a fact replaces an existing memory with outdated info, "remove" for ids the user contradicted. Empty arrays if nothing qualifies. Write facts in the third person, in English, max 140 chars each.' },
        { role: 'user', content: `Existing memories:\n${JSON.stringify(mems ?? [])}\n\nUser said: ${userMsg}\nAssistant replied: ${reply}` },
      ],
    })
    const j = JSON.parse(r.choices[0]?.message?.content || '{}')
    const ids = new Set((mems ?? []).map((m) => m.id))
    const add = (Array.isArray(j.add) ? j.add : []).filter((s: unknown) => typeof s === 'string' && s.trim()).slice(0, 5).map((content: string) => ({ user_id: userId, content: content.slice(0, 200) }))
    if (add.length) await sb.from('memories').insert(add)
    for (const u of Array.isArray(j.update) ? j.update.slice(0, 5) : []) if (ids.has(u?.id) && typeof u.content === 'string') await sb.from('memories').update({ content: u.content.slice(0, 200), updated_at: new Date().toISOString() }).eq('id', u.id)
    const rm = (Array.isArray(j.remove) ? j.remove : []).filter((id: string) => ids.has(id))
    if (rm.length) await sb.from('memories').delete().in('id', rm)
  } catch (e) { console.error('memory update failed', e) }
}
